/**
 * Package contains all the test cases that this framework needs to run.
 * 
 * @author Amuthan Sakthivel
 * @version 1.0
 * @since 1.0
 */
package com.tmb.tests;