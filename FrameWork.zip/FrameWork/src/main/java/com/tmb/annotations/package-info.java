/**
 * Package contains classes related to custom annotations built to be used in this framework
 * 
 * @author Amuthan Sakthivel
 * @version 1.0
 * @since 1.0
 */
package com.tmb.annotations;