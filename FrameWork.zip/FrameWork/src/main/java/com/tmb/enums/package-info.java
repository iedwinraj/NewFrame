/**
 * Package contains Enums that is used across the entire framework. See individual classes for more details.
 * 
 * @author Amuthan Sakthivel
 * @version 1.0
 * @since 1.0
 */
package com.tmb.enums;