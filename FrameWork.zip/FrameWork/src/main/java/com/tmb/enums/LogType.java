package com.tmb.enums;

public enum LogType {

    PASS,FAIL,SKIP,INFO,CONSOLE,EXTENTANDCONSOLE
}
