package com.tmb.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.tmb.constants.FrameworkConstants;
import com.tmb.exceptions.FrameworkException;
import com.tmb.exceptions.InvalidPathForExcelException;

/**
 * Utility class to read or write to excel.
 * 
 * <pre>
 * <b>
 * <a href="https://www.youtube.com/channel/UC6PTXUHb6j4Oxf0ccdRI11A">Testing Mini Bytes Youtube channel</a>
 * </b>
 * </pre>
 * 
 * Jan 22, 2021 
 * @author Amuthan Sakthivel
 * @version 1.0
 * @since 1.0
 * @see com.tmb.listeners.MethodInterceptor
 * @see DataProviderUtils
 */
public final class ExcelUtils {

	/**
	 * Private constructor to avoid external instantiation
	 */
	private ExcelUtils() {}


	/**
	 * Encapsulates all the value from the mentioned excel sheet and store it in
	 * List holding HashMaps. Key for the map in the column header in the excel sheet.
	 * 
	 * @author Amuthan Sakthivel
	 * Jan 22, 2021
	 * @param sheetname Excel sheetname to read the value from
	 * @return List where each index holds a map and Each map holds the details about the test
	 * TODO create reusable methods
	 */
	public static List<LinkedHashMap<String,String>> getTestDetails(String sheetname){
		List<LinkedHashMap<String, String>> list;

		try(FileInputStream fs = new FileInputStream(FrameworkConstants.getExcelpath())) {

			XSSFWorkbook workbook = new XSSFWorkbook(fs);
			XSSFSheet sheet = workbook.getSheet(sheetname);

			int lastrownum = sheet.getLastRowNum();
			int lastcolnum = sheet.getRow(0).getLastCellNum();

			LinkedHashMap<String,String> map =null;
			list = new ArrayList<>();

			for(int i=1; i<=lastrownum;i++) { 
				map = new LinkedHashMap<>(); 
				for(int j=0;j<lastcolnum;j++) {
					String key= sheet.getRow(0).getCell(j).getStringCellValue();
					System.out.println(key);
					String value = sheet.getRow(i).getCell(j).getStringCellValue();
					System.out.println(value);
					map.put(key, value);
				}
				list.add(map);
			}

		} catch (FileNotFoundException e) {
			throw new InvalidPathForExcelException("Excel File you trying to read is not found");
		} catch (IOException e) {
			throw new FrameworkException("Some io exception happened  while reading excel file");
		}
		System.out.println(list);
		return list;
	}
	
	
	
//	public String getCellValueAsString(Cell cell) {
//		String cellValue = null;
//		switch (cell.getCellType()) {
//		case NUMERIC:
//			cellValue = String.valueOf(cell.getNumericCellValue());
//			break;
//		case STRING:
//			cellValue = cell.getStringCellValue();
//			break;
//		case BOOLEAN:
//			cellValue = String.valueOf(cell.getBooleanCellValue());
//			break;
//		case FORMULA:
//			cellValue= cell.getCellFormula();
//		case BLANK:
//			cellValue="BLANK";
//		default:
//			cellValue ="DEFAULT";
//		}
//		return cellValue;
//	}
//	
	

}
