package com.tmb.pages;

public class EntitlementsPage extends BasePage {

}
