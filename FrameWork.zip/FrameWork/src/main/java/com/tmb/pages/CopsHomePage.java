package com.tmb.pages;

import org.openqa.selenium.By;

import com.tmb.enums.WaitStrategy;

public final class CopsHomePage extends BasePage {
	
	private final By linkWelcome = By.id("welcome");
	private final By linkLogout = By.xpath("//a[text()='Logout']");
	
	
	public CopsHomePage clickWelcome() {
		click(linkWelcome, WaitStrategy.PRESENCE,"Welcome link");
		return this;
	}
	
	
			
	public CopsLoginPage clickLogout() {
		click(linkLogout, WaitStrategy.CLICKABLE,"Logout button");
		return new CopsLoginPage();
	}
	

	
	
	//wait.until(d->d.findElement(link_logout).isEnabled()); //Java 8 way
}
