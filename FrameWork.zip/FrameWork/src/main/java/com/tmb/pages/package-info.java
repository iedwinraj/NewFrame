/**
 * Each class file here encapsulates the methods and elements of a particular webpage.
 * 
 * @author Amuthan Sakthivel
 * @version 1.0
 * @since 1.0
 */
package com.tmb.pages;