package com.tmb.pages;

public final class AmazonLaptopPage extends BasePage{
	
	public String getTitle() {
		return getPageTitle();
	}

}
