package com.tmb.pages;

import static com.tmb.enums.LogType.FAIL;
import static com.tmb.enums.LogType.PASS;
import static com.tmb.reports.FrameworkLogger.log;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.tmb.driver.DriverManager;
import com.tmb.enums.WaitStrategy;
import com.tmb.utils.DecodeUtils;

public final class CopsLoginPage extends BasePage{


	private final By textboxUsername = By.name("username");
	private final By textboxPassword = By.name("password");
	private final By buttonLogin = By.xpath("//button[@class='login-form-button bg-yellow fg-black ant-btn ng-tns-c119-2 ant-btn-default']");
	private By selectedCategory=By.name("selectedCategory");
	private By issue_summary=By.name("issue_summary");
	private By agent_name=By.name("agent_name");
	private By description=By.name("selectedCategory");
	private By cancelbtn=By.className("ant-btn ant-btn-default");
	private By errorMsg =By.className("ant-message");


	public CopsLoginPage enterUserName(String username) {
		
		sendKeys(textboxUsername, username, WaitStrategy.PRESENCE,"Username");
		return this;
	}

	public CopsLoginPage enterPassWord(String password) {
		sendKeys(textboxPassword, password, WaitStrategy.PRESENCE,"Password");
		return this;
	}
	public CopsHomePage clickLogin() {
		click(buttonLogin, WaitStrategy.PRESENCE, "Login Button");
		return new CopsHomePage();
	}
	
	
	public void verifyingErrorMsg(String username,String password) {
		
		enterUserName(username).enterPassWord(password).clickLogin();
		WebElement errorMsgs = DriverManager.getDriver().findElement(errorMsg);
		if (errorMsgs.isDisplayed()) {
			System.out.println(errorMsgText());
			log(PASS,errorMsgs+" ErrorMsg is Displayed");
		} else {
			log(FAIL,errorMsgs+" ErrorMsg is Displayed");
		}

	}
	
	
private  CopsLoginPage errorMsgText() {
	
    doGetText(errorMsg,WaitStrategy.PRESENCE , "ErrorMsg");
    return this;
    

}
	
	
	
}
