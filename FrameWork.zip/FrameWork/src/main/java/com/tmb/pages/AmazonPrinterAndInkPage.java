package com.tmb.pages;

public class AmazonPrinterAndInkPage extends BasePage {

}
